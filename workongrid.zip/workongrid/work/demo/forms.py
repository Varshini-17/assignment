from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms
from django.core.exceptions import ValidationError
from models import *
from django.forms import ModelForm
from django.core.validators import MaxLengthValidator


class CronForm(forms.Form):
	col1 = [(i, i.name) for i in table1._meta.get_fields()]
	col1.insert(0,("0","Column1"))
	column1=forms.ChoiceField(label="column1",
                               choices=col1)
	col2 = [(i, i.name) for i in table1._meta.get_fields()]
	col2.insert(0,("0","Column2"))
	column2=forms.ChoiceField(label="column2",
                               choices=col2)
	# column = forms.ModelChoiceField(queryset=table1._meta.get_fields())	

class Payload3(forms.Form):
	col_choices = [(i, i.name) for i in table1._meta.get_fields()]
	col_choices.insert(0,("0","column for operation"))
	column=forms.ChoiceField(label="column",
                               choices=col_choices)
	# choice2=[i for i in ['sum','avg','count','min','max','distinct count']]
	choice2 =(
	("0", "Choose Operation"), 
    ("1", "sum"), 
    ("2", "avg"), 
    ("3", "count"), 
    ("4", "min"), 
    ("5", "max"), 
    ("6", "distinct count"), 
) 
	operation=forms.ChoiceField(label='opr', choices=choice2)
	group_choices=col_choices
  	group_choices.insert(0,("0","group by"))
	group=forms.ChoiceField(label='group',
                               choices=group_choices)