# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from models import *
from django.shortcuts import render,redirect
from django.http.response import HttpResponse, JsonResponse
from django.apps import apps
from forms import *
from django.db.models import Min,Max,Avg,Sum,Count
# Create your views here.
def index(request):
	form=CronForm()
	form1=Payload3()
	print(form1)
	return render(request,"home.html",{"form":form,"form1":form1})
def payload1(request):
	dict={}
	if request.POST:
		database=request.POST.get('database_name')
		table=str(request.POST.get('table_name'))
		model=apps.get_model('demo', 'table1')
		field_name=model._meta.get_fields()
		field_data=model.objects.using(database).values_list()
		dict={"column":[item.name for item in field_name],"data":[item for item in field_data]}
		length=len(dict)
		dict.update({"length":length})
	return JsonResponse(dict,safe=False)

def payload2(request):
	if request.POST:
		database=request.POST.get('database_name')
		table=str(request.POST.get('table_name'))
		model=apps.get_model('demo', 'table1')
		column1=(request.POST.get('column1')).split(".")[-1]
		column2=(request.POST.get('column2')).split(".")[-1]
		values=model.objects.using(database).values_list(column1,column2)
		data={"column":[column1,column2], "data":[item for item in values]}
		length=len(data)
		data.update({"length":length})
	return JsonResponse(data,safe=False)

def payload3(request):
	result=[]
	if request.POST:
		database=request.POST.get('database_name')
		table=str(request.POST.get('table_name'))
		model=apps.get_model('demo', 'table1')
		column=(request.POST.get('column')).split(".")[-1]
		operation=(request.POST.get('operation'))
		group=request.POST.get('group').split(".")[-1]
		print("operation",operation)
		print("column",column,"group",group)
		if operation=='1':	#sum
			values=model.objects.using(database).values_list(group).annotate(total=Sum(column))
			for i in values:
				result.append(i)
			data={"column":[group,'sum_of_'+column],"data":result}
		if operation=='2':	#average
			values=model.objects.using(database).values_list(group).annotate(total=Avg(column))
			for i in values:
				result.append(i)
			data={"column":[group,'average_of_'+column],"data":result}
		if operation=='3':	#count
			values=model.objects.using(database).values_list(group).annotate(total=Count(column))
			for i in values:
				result.append(i)
			data={"column":[group,'count_of_'+column],"data":result}
		if operation=='4':	#minimum
			values=model.objects.using(database).values_list(group).annotate(Min(column))
			for i in values:
				result.append(i)
			data={"column":[group,'min_of_'+column],"data":result}
		if operation=='5':	#maximum
			values=model.objects.using(database).values_list(group).annotate(max=Max(column))
			for i in values:
				result.append(i)
			data={"column":[group,'max_of_'+column],"data":result}
		if operation=='6':	#distinct count
			
			values=model.objects.using(database).values_list(group).annotate(Count(column)).distinct()
			for i in values:
				result.append(i)
			data={"column":[group,'distinct_count_of_'+column],"data":result}
	return JsonResponse(data,safe=False)

