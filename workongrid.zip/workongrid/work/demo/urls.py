from django.conf.urls import url,include

from . import views

urlpatterns = [
    url('index', views.index, name='index'),
    url('payload1', views.payload1, name='payload1'),
    url('payload2', views.payload2, name='payload2'),
    url('payload3', views.payload3, name='payload3'),     
]