# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class table1(models.Model):
	userid=models.CharField(max_length=50)
	uploaded_time=models.DateTimeField()
	city=models.CharField(max_length=50)
	price=models.CharField(max_length=50)
	year=models.IntegerField(max_length=50)
	county_name=models.CharField(max_length=50)
	state_code=models.CharField(max_length=50)
	state_name=models.CharField(max_length=50)